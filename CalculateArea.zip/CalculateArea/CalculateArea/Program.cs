﻿// See https://aka.ms/new-console-template for more information

try
{
    Console.WriteLine("Enter the length of three sides of triangle in meter unit");

    double side1, side2, side3;
    do
    {
        Console.WriteLine("Side 1");
        string input = Console.ReadLine().Trim();

        if (!double.TryParse(input, out side1))
        {
            Console.WriteLine("Invalid input for Side 1");
            Console.WriteLine("Enter a valid value for Side 1");
        }

    } while (side1 <=0);

    do
    {
        Console.WriteLine("Side 2");
        string input = Console.ReadLine().Trim();
        if (!double.TryParse(input, out side2))
        {
            Console.WriteLine("Invalid input for Side 2");
            Console.WriteLine("Enter a valid value for Side 2");
        }

    } while (side2<=0);

    do
    {
        Console.WriteLine("Side 3");
        string input = Console.ReadLine().Trim();
        if (!double.TryParse(input, out side3))
        {
            Console.WriteLine("Invalid input for Side 3");
            Console.WriteLine("Enter a valid value for Side 3");
        }

    } while (side3<=0);

    //Calculate semi perimeter 
    double s = (side1 + side2 + side3) / 2;
    // I have applied Heron's formula 
    double area = Math.Sqrt(s * (s - side1) * (s - side2) * (s - side3));
    Console.WriteLine($"Area of the trianle is {area} square meter");
}
catch(Exception ex)
{
    Console.WriteLine($"An error occured {ex.Message}");
}
